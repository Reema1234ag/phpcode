<!DOCTYPE html>
<html>
<head>
    <title>Result</title>
</head>
<body>
<table border="2"> 
    <h2>Basic Details</h2>
    <tr>
        <th>S.no</hd>
        <th>Center code</th>
        <th>Centre name</th>
        <th>Centre city</th>
        <th>Auditor firstname</th>
        <th>Auditor lastname</th>
        <th>Auditor Contact</th>
        <th>Audit Date</th>
        <th>Centre Admin</th>
        <th>Admin Contact</th>
        <th>Centre IT Head</th>
        <th>IT Head Contact</th>
        <th>Centre Network Head</th>
        <th>Network Head Contact</th>
        <th>PC's can booked</th>
        <th>BusStand distance(km)</th>
        <th>Railway distance(km)</th>
        <th>City distance(km)</th>
        <th>Computer labs</th>
        <th>On floors</th>
        <th>PH friendly</th>
        <th>Lift avail</th>
        <th>Waiting Space</th>
        <th>Queueing Space</th>
        <th>screening Space</th>
        <th>Regis desk</th>
        <th>Server Room</th>
    </tr>
<?php
include('../forms/config.php');
$query= "select * from test_centre_report";
$data=mysqli_query($con,$query);
$total=mysqli_num_rows($data);
//echo "$total";
if($total!=0){
    while(($result=mysqli_fetch_assoc($data))){
        echo "
        <tr>
        <td>".$result['Snum']."</td>
        <td>".$result['centre_code']."</td>
        <td>".$result['centre_name']."</td>
        <td>".$result['city']."</td>
        <td>".$result['auditor_firstname']."</td>
        <td>".$result['auditor_lastname']."</td>
        <td>".$result['auditor_contact']."</td>
        <td>".$result['audit_date']."</td>
        <td>".$result['centre_admin_name']."</td>
        <td>".$result['centre_admin_contact']."</td>
        <td>".$result['centre_IThead_name']."</td>
        <td>".$result['centre_IThead_contact']."</td>
        <td>".$result['centre_network_name']."</td>
        <td>".$result['centre_network_contact']."</td>
        <td>".$result['PCs_booked']."</td>
        <td>".$result['distance_BusStand']."</td>
        <td>".$result['distance_railway']."</td>
        <td>".$result['distance_city']."</td>
        <td>".$result['computer_labs']."</td>
        <td>".$result['floors']."</td>
        <td>".$result['PH_friendly']."</td>
        <td>".$result['lift_availability']."</td>
        <td>".$result['waiting_space']."</td>
        <td>".$result['queuing_space']."</td>
        <td>".$result['screening_facility']."</td>
        <td>".$result['regis_desk']."</td>
        <td>".$result['server_room']."</td>
        </tr>
        ";
    }
}
else echo "Oops! No record found";
?>
</table>
<form>
    <input type="file" name="excel.file"/>
    <input type="submit" name="import" value="Import"/>
</form>
</body>
</html>