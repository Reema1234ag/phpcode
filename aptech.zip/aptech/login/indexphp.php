<?php
include("./indexconfig.php");
if($_SERVER['REQUEST_METHOD']=="POST")
if(isset($_POST['emp_b']))
{   
    $emp_id=$_POST['emp_id'];
    $emp_pass=$_POST['emp_pass'];
    if(!empty($emp_id) && !empty($emp_pass))
    {
        $query = "select * from employee where emp_id = '$emp_id' limit 1";

			$result=mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['emp_pass'] === $emp_pass)
					{

						// $_SESSION['user_id'] = $user_data['user_id'];
						header("Location: ../forms/Basic_details.php");
						die;
					}
                    else{
                         echo "<script> alert('Wrong Password!');window.location='index.php'</script>";
                    }
				}

            }
            echo "<script> alert('Wrong Username!');window.location='index.php'</script>";
    }
    
    // else{
    //     echo "enter details";
    // }
}
else
{   
    $admin_id=$_POST['admin_id'];
    $admin_pass=$_POST['admin_pass'];
    if(!empty($admin_id) && !empty($admin_pass))
    {
        $query = "select * from admin where admin_id = '$admin_id' limit 1";

			$result=mysqli_query($con, $query);

			if($result)
			{
				if($result && mysqli_num_rows($result) > 0)
				{

					$user_data = mysqli_fetch_assoc($result);
					
					if($user_data['admin_pass'] === $admin_pass)
					{

						// $_SESSION['user_id'] = $user_data['user_id'];
						header("Location: ../admin/admin.php");
						die;
					}
                    else{
                         echo "<script> alert('Wrong Password!');window.location='index.php'</script>";
                    }
				}

            }
            echo "<script> alert('Wrong Username!');window.location='index.php'</script>";
    }
    
    // else{
    //     echo "enter details";
    // }
}

?>