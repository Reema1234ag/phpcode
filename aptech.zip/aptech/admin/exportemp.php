<?php  
//export.php  
$connect = mysqli_connect("localhost", "root", "", "login");
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM employee";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                    <th>emp_id</th>  
                    <th>emp_firstname</th>  
                    <th>emp_lastname</th>  
                    <th>emp_contact</th>
                    <th>emp_pass</th>
                    <th>emp_base_location</th>
                    <th>emp_reportingTo</th>
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
   <tr>  
   <td>'.$row["emp_id"].'</td>  
   <td>'.$row["emp_firstname"].'</td>  
   <td>'.$row["emp_lastname"].'</td>  
   <td>'.$row["emp_contact"].'</td>  
   <td>'.$row["emp_pass"].'</td>
   <td>'.$row["emp_base_location"].'</td>
   <td>'.$row["emp_reportingTo"].'</td>
 </tr>  
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>