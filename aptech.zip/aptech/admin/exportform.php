<?php  
//export.php  
$connect = mysqli_connect("localhost", "root", "", "testcentreaudit");
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM test_centre_report";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                    <th>centre_code</th>  
                    <th>centre_name</th>  
                    <th>city</th>  
                    <th>auditor_firstname</th>
                    <th>auditor_lastname</th>
                    <th>auditor_contact</th>
                    <th>audit_date</th>
                    <th>centre_admin_name</th>
                    <th>centre_admin_contact</th>
                    <th>centre_IThead_name</th>
                    <th>centre_IThead_contact</th>
                    <th>centre_network_name</th>
                    <th>centre_network_contact</th>
                    <th>PCs_booked</th>
                    <th>distance_BusStand</th>
                    <th>distance_railway</th>
                    <th>distance_city</th>
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
    <td>'.$row["centre_code"].'</td>  
    <td>'.$row["centre_name"].'</td>  
    <td>'.$row["city"].'</td>  
    <td>'.$row["auditor_firstname"].'</td>  
    <td>'.$row["auditor_lastname"].'</td>
    <td>'.$row["auditor_contact"].'</td>
    <td>'.$row["audit_date"].'</td>
    <td>'.$row["centre_admin_name"].'</td>
    <td>'.$row["centre_admin_contact"].'</td>
    <td>'.$row["centre_IThead_name"].'</td>
    <td>'.$row["centre_IThead_contact"].'</td>
    <td>'.$row["centre_network_name"].'</td>
    <td>'.$row["centre_network_contact"].'</td>
    <td>'.$row["PCs_booked"].'</td>
    <td>'.$row["distance_BusStand"].'</td>
    <td>'.$row["distance_railway"].'</td>
    <td>'.$row["distance_city"].'</td>
  </tr>  
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>