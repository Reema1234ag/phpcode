<?php
include("../login/indexconfig.php");
include("../login/adminfunctions.php");
$admin_data=check_loginn($con1);
if($_SERVER['REQUEST_METHOD']=="POST")
if(isset($_POST['addemp']))
{
        $emp_id = $_POST['emp_id'];
        $emp_firstname = $_POST['emp_firstname'];
        $emp_lastname = $_POST['emp_lastname'];
        $emp_contact = $_POST['emp_contact'];
        $emp_pass = $_POST['emp_pass'];
        $emp_base_location = $_POST['emp_base_location'];
        $emp_reportingTo = $_POST['emp_reportingTo'];
             //save to database
			//$user_id = random_num(20);
		$query = "insert into employee(emp_id,emp_firstname,emp_lastname,emp_contact,emp_pass,emp_base_location,
        emp_reportingTo) 
        values ('$emp_id','$emp_firstname','$emp_lastname','$emp_contact','$emp_pass','$emp_base_location',
        '$emp_reportingTo')";

		mysqli_query($con1, $query);

		header("Location: adminn.php");
		die;
		
}
if(isset($_POST['fetch'])){
    $entered_code = $_POST['entered_code'];
    if ($entered_code==='all')
    header("location:./fetching1.php");
    else echo "<script> alert('oops no record found');window.location='./adminn.php'</script>";

}
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title>admin</title>

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="../CSS/adminn.css">
</head>

<body>



    <div class="wrapper">
        <!-- Sidebar Holder -->
        <nav id="sidebar">
            <div class="sidebar-header">
                <h3>Admin</h3>
                <strong>BS</strong>
            </div>

            <ul class="list-unstyled components">
                <li>
                    <a href="./empdetails.php">
                        <i class="	glyphicon glyphicon-user"></i>
                        Employee details
                    </a>

                    <a href="#">
                        <i class="glyphicon glyphicon-briefcase"></i>
                        <span data-toggle="modal" data-target="#exampleModalLong">Add Employee</span>
                    </a>
                    <a href="#">
                        <i class="glyphicon glyphicon-duplicate"></i>
                        <span data-toggle="modal" data-target="#Import">Import Data</span>
                    </a>
                    <a href="#">
                        <i class="glyphicon glyphicon-duplicate"></i>
                        <span data-toggle="modal" data-target="#fetching">Fetching</span>
                    </a>
                    <a href="#">
                        <i class="glyphicon glyphicon-duplicate"></i>
                        <span data-toggle="modal" data-target="#Profile">View Profile</span>
                    </a>
                </li>
            </ul>

            <!-- <ul class="list-unstyled CTAs">
                <li><a href="#" class="download">Download Data</a>
                </li>
                <li><a href="#" class="article">Back to article</a></li>
            </ul> -->
        </nav>

        <!-- Page Content Holder -->
        <div id="content">

            <nav class="navbar navbar-default">
                <div class="container-fluid">

                    <div class="navbar-header">
                        <button type="button" id="sidebarCollapse" class="btn btn-info navbar-btn">
                            <i class="glyphicon glyphicon-align-left"></i>
                            <!-- <span>Toggle Sidebar</span> -->
                        </button>
                    </div>

                    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                        <ul class="nav navbar-nav navbar-right">
                            <li><a href="./adminn.php">Home</a></li>
                            <li><a href="#">Profile</a></li>
                            <li><a href="#">Contact</a></li>
                            <li><a href="#">Logout</a></li>
                        </ul>
                    </div>
                </div>
            </nav>
            <!-- Button trigger modal -->
            <!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModalLong">
                Launch demo modal
            </button> -->
            <!-- fetching -->
            <div class="modal fade" id="fetching" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Fatch Data</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form method="post">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="" name="entered_code"placeholder="Enter Center code" required>
                                </div>
                                <!-- <div class="form-group">
                                    <input type="text" class="form-control" id="" placeholder="Filter Key">
                                </div> -->
                                <div class="form-group">
                                    <input type="number" class="form-control" id="" placeholder="Number Of Rows">
                                </div>
                                <!-- <div class="form-group">
                                    <input type="text" class="form-control" id="" placeholder="Enter data column ypu want">
                                </div> -->
                            <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" name="fetch" class="btn btn-primary">Fetch</button>
                            </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- add employee -->
            <div class="modal fade" id="exampleModalLong" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle"> Fill Employee Details</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <form method="post">
                                <div class="form-group">
                                    <input type="text" class="form-control" id="" name="emp_id" placeholder="Employee Id">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="" name="emp_firstname"  placeholder="Employee First name">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="" name="emp_lastname"  placeholder="Employee last  name">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="" name="emp_contact"  placeholder="Employee Contact">
                                </div>
                                <div class="form-group">
                                    <input type="password" class="form-control" name="emp_pass"  id="" placeholder="password">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="" name="emp_base_location"  placeholder="Employee Base Location">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" id="" name="emp_reportingTo"  placeholder="Employee Report to">
                                </div>
                        
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                            <button type="submit" name="addemp"class="btn btn-primary">Save changes</button>
                        </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Import model  -->
            <div class="modal fade" id="Import" tabindex="-1" role="dialog"
                aria-labelledby="exampleModalLongTitle" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="exampleModalLongTitle">Modal title</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </dcomposer require phpoffice/phpspreadsheetiv>
                        <div class="modal-body">
                            <form action="" method="POST" enctype = "multipart/form-control">
                                <input type="file" name="import_file" class="form-control">
                                
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-primary" data-dismiss="modal">Import</button>
                            <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
                        </div>
                    </div>
                </div>
            </div>
            
        </div>
    </div>





    <!-- jQuery CDN -->
    <script src="https://code.jquery.com/jquery-1.12.0.min.js"></script>
    <!-- Bootstrap Js CDN -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
            });
        });
    </script>
</body>

</html>