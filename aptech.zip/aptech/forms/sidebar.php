<?php?>
<nav id="sidebar">
    <div class="sidebar-header">
        <h3>Test-Centre Audit</h3>
    </div>

    <ul class="list-unstyled components">
        <p>Forms</p>
        <li>
            <a href="./Basic_details.php">Basic details</a>
        </li>
        <li>
            <a href="./Desktop_config.php">Desktop configuration</a>
            <!-- <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false"
                class="dropdown-toggle">Pages</a>
            <ul class="collapse list-unstyled" id="pageSubmenu">
                <li>
                    <a href="#">Page 1</a>
                </li>
                <li>
                    <a href="#">Page 2</a>
                </li>
                <li>
                    <a href="#">Page 3</a>
                </li>
            </ul> -->
        </li>
        <li>
            <a href="./Power_backup.php">Power backup</a>
        </li>
        <li>
            <a href="./Internet_line1.php">Internet Line</a>
        </li>
        <li>
            <a href="./Network_details.php">Network Details</a>
        </li>
        <li>
            <a href="./Other_info.php">Other Information</a>
        </li>
    </ul>
    <!-- <button class="btn btn-primary"><a href="../Results/result1.php">Fetch</a></button> -->
    <ul class="list-unstyled CTAs">
        <li>
            <a href="#" class="download">SAVE</a>
        </li>
    </ul>
</nav>