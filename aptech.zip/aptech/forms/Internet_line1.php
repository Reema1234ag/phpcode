<?php 
    session_start();
    include("../login/indexconfig.php");
    include("../login/functions.php");
    $emp_data=check_login($con1);
    $emp_id=$emp_data['emp_id'];
    if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
        $internet = $_POST['internet'];
		$connection_type = $_POST['connection_type'];
        $service_provider = $_POST['service_provider'];
        $internet_bandwidth = $_POST['internet_bandwidth'];
        $for_IBT = $_POST['for_IBT'];
        $clg_bandwidth = $_POST['clg_bandwidth'];

        $backup_net=$_POST['backup_net'];
        $b_connection_type = $_POST['b_connection_type'];
        $b_service_provider = $_POST['b_service_provider'];
        $b_internet_bandwidth = $_POST['b_internet_bandwidth'];
        $b_for_IBT = $_POST['b_for_IBT'];

        if($internet==="No"){
            $connection_type="NA";
            $service_provider="NA";
            $internet_bandwidth="NA";
            $for_IBT="NA";
            $clg_bandwidth="NA";

        }
        if($backup_net==="No"){
            $b_connection_type="NA";
            $b_service_provider="NA";
            $b_internet_bandwidth="NA";
            $b_for_IBT="NA";

        }

        if(!empty($connection_type) && !empty($service_provider) && !empty($internet_bandwidth) && !empty($for_IBT) && !empty($clg_bandwidth)
        && !empty($b_connection_type)&& !empty($b_service_provider)&& !empty($b_internet_bandwidth)&& !empty($b_for_IBT))
        {   //save to database
			//$user_id = random_num(20);
			$query = "insert into internet_line1(internet,connection_type,service_provider,internet_bandwidth,for_IBT,clg_bandwidth,backup_net,
            b_connection_type,b_service_provider,b_internet_bandwidth,b_for_IBT) 
            values ('$internet','$connection_type','$service_provider','$internet_bandwidth','$for_IBT','$clg_bandwidth','$backup_net',
            '$b_connection_type','$b_service_provider','$b_internet_bandwidth','$b_for_IBT')";

			mysqli_query($con2, $query);

			header("Location: Backup_internet.php");
			die;
		}
        else
		{
			echo "<script> alert('Please enter the details required');window.location='Internet_line1.php'</script>";
		}
    }
?>
<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <title></title>

    <!-- Bootstrap CSS CDN -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css"
        integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <!-- Our Custom CSS -->
    <link rel="stylesheet" href="../CSS/index.css">

    <!-- Font Awesome JS -->
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js"
        integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ"
        crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js"
        integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY"
        crossorigin="anonymous"></script>

</head>

<body onload="nonet(),nobackup()">

    <div class="wrapper">
        <!-- Sidebar Holder -->
        <?php include 'sidebar.php'?>

        <!-- Page Content Holder -->
        <div id="content">

        <?php include 'topbar.php'?>
            <h2 id="heading">Internet Line</h2><hr>

            <form id="form" method="post">
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Internet connection Available?</label>
                        <div class="form-check">
                        <input class="form-check-input" type="radio" name="internet" onclick="yesnet();" value="Yes"id="flexRadioDefault1">YES<br>
                        <input class="form-check-input" type="radio" name="internet" onclick="nonet();" value="No"id="flexRadioDefault1">NO
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div id="div1" class="form-group col-md-6">
                        <label for="inputEmail4">Type of internet connection</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="connection_type" value="Broadband"
                            id="flexRadioDefault1">Broadband
                            <br>
                            <input class="form-check-input" type="radio" name="connection_type" value="Lease Line" id="flexRadioDefault1">
                            Lease Line
                        </div>
                    </div>
                    
                </div>
                <div class="form-row">
                    <div id="div2" class="form-group col-md-6">
                        <label for="inputEmail4">Name of internet Service Provider</label>
                        <input type="text" class="form-control" id="inputEmail4" placeholder="Service Providers" name="service_provider">
                    </div>
                    
                </div>
                <div class="form-row">
                    <div id="div3" class="form-group col-md-6">
                        <label for="inputEmail4">Internet Bandwidth (in MBPS)</label>
                        <input type="number" class="form-control" id="inputEmail4" placeholder="in MBPS" name="internet_bandwidth">
                    </div>
                    
                </div>
                <div class="form-row">
                    <div id="div4" class="form-group col-md-6">
                        <label for="inputEmail4">Suitable for IBT?</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="for_IBT" value="Yes" id="flexRadioDefault1">YES
                            <br>
                            <input class="form-check-input" type="radio" name="for_IBT" value="No" id="flexRadioDefault1">NO
                        </div>
                    </div>
                    
                </div>  
                 <div class="form-row">
                    <div id="div5" class="hide">
                        <label for="inputEmail4">How much Internet Bandwidth will college provide during Exam?</label>
                        <input type="number" class="form-control" id="inputEmail4" name="clg_bandwidth"placeholder="Internet Bandwidth">
                    </div>
                    
                </div>
                <hr>
                <hr>
                <!-- addling backup internet from----------------------- ///////////////////////////////////////////////////-->
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Back-up Internet Availability?</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="backup_net" value="Yes"onclick="yesbackup();" id="flexRadioDefault1">YES
                            <br>
                            <input class="form-check-input" type="radio" name="backup_net" value="No" onclick="nobackup();" id="flexRadioDefault1">NO
                        </div>
                    </div>
                    
                </div>
                <div class="form-row">
                    <div id="div6" class="form-group col-md-6">
                    <label for="inputEmail4">Type of Internet connection(Backup)?</label>
                    <div class="form-check">
                    <input class="form-check-input" type="radio" name="b_connection_type" value="Broadband" id="flexRadioDefault1">Broadband
                        <br>
                    <input class="form-check-input" type="radio" name="b_connection_type" value="Lease Line"id="flexRadioDefault1">Lease Line
                    </div>
                    </div>
                </div>
                <div class="form-row">
                    <div id="div7" class="form-group col-md-6">
                        <label for="inputEmail4">Name of internet Service Provider(Backup)?</label>
                        <input type="text" class="form-control" id="inputEmail4" name="b_service_provider"placeholder="service provider">
                    </div>
                    
                </div>
                <div class="form-row">
                    <div id="div8" class="form-group col-md-6">
                    <label for="inputEmail4">Internet Bandwidth (Backup)</label>
                    <input type="number" class="form-control" id="inputEmail4" name="b_internet_bandwidth" placeholder="IN MBPS">
                    </div>
                    
                </div>
                <div class="form-row">
                    <div id="div9" class="form-group col-md-6">
                        <label for="inputEmail4">Suitable for IBT(Backup)?</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" name="b_for_IBT" value="Yes" id="flexRadioDefault1">YES
                            <br>
                            <input class="form-check-input" type="radio" name="b_for_IBT" value="No" id="flexRadioDefault1">NO
                        </div>
                    </div>
                    
                </div>
                
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>

    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"
        integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ"
        crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"
        integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm"
        crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
                $(this).toggleClass('active');
            });
        });
    </script>
    <script>
        function nonet() {
            document.getElementById('div1').style.display = 'none';
            document.getElementById('div2').style.display = 'none';
            document.getElementById('div3').style.display = 'none';
            document.getElementById('div4').style.display = 'none';
            document.getElementById('div5').style.display = 'none';

        }
        function yesnet() {
            document.getElementById('div1').style.display = 'block';
            document.getElementById('div2').style.display = 'block';
            document.getElementById('div3').style.display = 'block';
            document.getElementById('div4').style.display = 'block';
            document.getElementById('div5').style.display = 'block';
        }
        function yesbackup() {
            document.getElementById('div6').style.display = 'block';
            document.getElementById('div7').style.display = 'block';
            document.getElementById('div8').style.display = 'block';
            document.getElementById('div9').style.display = 'block';
        }
        function nobackup() {
            document.getElementById('div6').style.display = 'none';
            document.getElementById('div7').style.display = 'none';
            document.getElementById('div8').style.display = 'none';
            document.getElementById('div9').style.display = 'none';
        }
    </script>
</body>

</html>