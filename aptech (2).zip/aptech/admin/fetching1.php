<?php
$connect = mysqli_connect("localhost", "root", "", "testcentreaudit");
$sql = "SELECT * FROM test_centre_report";  
$result = mysqli_query($connect, $sql);
$total=mysqli_num_rows($result);
//echo "$total";
?>
<html>  
 <head>  
  <title>Export data to Excel</title>  
   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
 </head>  
 <body>  
  <div class="container">  
   <br />  
   <br />  
   <br />  
   <div class="table-responsive">  
    <h2 align="center">Forms Data</h2><br /> 
    <table class="table table-bordered">
     <tr>  
                        <th>centre_code</th>  
                        <th>centre_name</th>  
                        <th>city</th>  
                        <th>auditor_firstname</th>
                        <th>auditor_lastname</th>
                        <th>auditor_contact</th>
                        <th>audit_date</th>
                        <th>centre_admin_name</th>
                        <th>centre_admin_contact</th>
                        <th>centre_IThead_name</th>
                        <th>centre_IThead_contact</th>
                        <th>centre_network_name</th>
                        <th>centre_network_contact</th>
                        <th>PCs_booked</th>
                        <th>distance_BusStand</th>
                        <th>distance_railway</th>
                        <th>distance_city</th>
                    </tr>
     <?php
     if($total!=0){
     while($row = mysqli_fetch_array($result))  
     {  
        echo '  
       <tr>  
         <td>'.$row["centre_code"].'</td>  
         <td>'.$row["centre_name"].'</td>  
         <td>'.$row["city"].'</td>  
         <td>'.$row["auditor_firstname"].'</td>  
         <td>'.$row["auditor_lastname"].'</td>
         <td>'.$row["auditor_contact"].'</td>
         <td>'.$row["audit_date"].'</td>
         <td>'.$row["centre_admin_name"].'</td>
         <td>'.$row["centre_admin_contact"].'</td>
         <td>'.$row["centre_IThead_name"].'</td>
         <td>'.$row["centre_IThead_contact"].'</td>
         <td>'.$row["centre_network_name"].'</td>
         <td>'.$row["centre_network_contact"].'</td>
         <td>'.$row["PCs_booked"].'</td>
         <td>'.$row["distance_BusStand"].'</td>
         <td>'.$row["distance_railway"].'</td>
         <td>'.$row["distance_city"].'</td>
       </tr>  
        ';  
     }
    }
    else echo "Oops! No record found";
     ?>
    </table>
    <br />
    <form method="post" action="./exportform.php">
     <input type="submit" name="export" class="btn btn-success" value="Export" />
    </form>
   </div>  
  </div>  
 </body>  
</html>
