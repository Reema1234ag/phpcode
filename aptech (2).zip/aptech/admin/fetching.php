<?php
$connect = mysqli_connect("localhost", "root", "", "testcentreaudit");
$sql = "SELECT * FROM network_details";  
$result = mysqli_query($connect, $sql);
?>
<html>  
 <head>  
  <title>Export MySQL data to Excel in PHP</title>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
 </head>  
 <body>  
  <div class="container">  
   <br />  
   <br />  
   <br />  
   <div class="table-responsive">  
    <h2 align="center">Export MySQL data to Excel in PHP</h2><br /> 
    <table class="table table-bordered">
     <tr>  
                        <th>network_topology</th>  
                        <th>type_network</th>  
                        <th>cabling_structure</th>  
                        <th>isolated_network</th>
                        <th>proxy_config</th>
                        <th>power_backup</th>
                        <th>type_structured_network</th>
                        <th>LAN</th>
                        <th>clg_network</th>
                    </tr>
     <?php
     while($row = mysqli_fetch_array($result))  
     {  
        echo '  
       <tr>  
         <td>'.$row["network_topology"].'</td>  
         <td>'.$row["type_network"].'</td>  
         <td>'.$row["cabling_structure"].'</td>  
         <td>'.$row["isolated_network"].'</td>  
         <td>'.$row["proxy_config"].'</td>
         <td>'.$row["power_backup"].'</td>
         <td>'.$row["type_structured_network"].'</td>
         <td>'.$row["LAN"].'</td>
         <td>'.$row["clg_network"].'</td>
       </tr>  
        ';  
     }
     ?>
    </table>
    <br />
    <form method="post" action="./export.php">
     <input type="submit" name="export" class="btn btn-success" value="Export" />
    </form>
   </div>  
  </div>  
 </body>  
</html>
