<?php  
//export.php  
$connect = mysqli_connect("localhost", "root", "", "testcentreaudit");
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM network_details";
 $result = mysqli_query($connect, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
                    <tr>  
                        <th>network_topology</th>  
                        <th>type_network</th>  
                        <th>cabling_structure</th>  
                        <th>isolated_network</th>
                        <th>proxy_config</th>
                        <th>power_backup</th>
                        <th>type_structured_network</th>
                        <th>LAN</th>
                        <th>clg_network</th>
                    </tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
    <tr>  
                         <td>'.$row["network_topology"].'</td>  
                         <td>'.$row["type_network"].'</td>  
                         <td>'.$row["cabling_structure"].'</td>  
                         <td>'.$row["isolated_network"].'</td>  
                         <td>'.$row["proxy_config"].'</td>
                         <td>'.$row["power_backup"].'</td>
                         <td>'.$row["type_structured_network"].'</td>
                         <td>'.$row["LAN"].'</td>
                         <td>'.$row["clg_network"].'</td>
                    </tr>
   ';
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>