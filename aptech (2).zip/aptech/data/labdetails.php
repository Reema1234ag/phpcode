<?php
    session_start();
    include("../login/indexconfig.php");
    include("../login/functions.php");
    $emp_data=check_login($con1);
    $emp_id=$emp_data['emp_id'];
    if($_SERVER['REQUEST_METHOD']=="POST")
    if(isset($_POST['lab']))
    {
    $wifi=$_POST['wifi'];
    $num_system_wifi = $_POST['num_system_wifi'];
    $printers = $_POST['printers'];
    $type_printer = $_POST['type_printer'];
    $ac_avail = $_POST['ac_avail'];
    $cctv_avail = $_POST['cctv_avail'];
    $drinking_water = $_POST['drinking_water'];
    $has_bell = $_POST['has_bell'];
    $sep_frisking_area = $_POST['sep_frisking_area'];
    $thermal_guns = $_POST['thermal_guns'];

    if($wifi==="No"){
        $num_system_wifi="NA";
    }
    if(!empty($num_system_wifi)){
    $query="insert into other_info(emp_id,wifi,num_system_wifi,printers,type_printer,ac_avail,cctv_avail,drinking_water,
    has_bell,sep_frisking_area,thermal_guns)
    values('$emp_id','$wifi','$num_system_wifi','$printers','$type_printer','$ac_avail','$cctv_avail',
    '$drinking_water','$has_bell','$sep_frisking_area','$thermal_guns')";
    mysqli_query($con2,$query);
    header("location: ../forms/thankyou.html");
    }
    else{
        echo "<script> alert('Please enter the details required');window.location='Other_info.php'</script>";
    }
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    
    <link rel="stylesheet" href="../CSS/mainstyle.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>


    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script> 
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>
    <link
      href="https://fonts.googleapis.com/css2?family=Roboto:wght@100;400&display=swap"
      rel="stylesheet"
    />
    
    <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    
    <!--<title>Dashboard Sidebar Menu</title>--> 
  <style>
      body {
        font-family: "Roboto", sans-serif;
      }
      h1 {
        text-align: center;
        display:block;
        /* background-color:#7386d5; */
      }
      table,
      form {
        width: 500px;
        margin: 20px auto;
      }
      table {
        border-collapse: collapse;
        text-align: center;
        border:0;
        
      }
      table td,
      table th 
      {
/*         border: solid 1px black; */
      }
      label,
      input {
        display: block;
        margin: 10px 0;
        font-size: 20px;
      }
      button {
        display: block;
      }
  </style>
</head>
<body>
    <?php include("sidenav.php");?>

<section class="home">
    <div class="text">
        <h2 id="heading">Lab Details</h2><hr>
        <form>
      <div class="input-row">
        <label for="lab">lab number</label>
        <input type="text" name="lab" id="lab" />
      </div>
      <div class="input-row">
        <label for="Systems">No of Systems</label>
        <input type="text" name="Systems" id="Systems" />
      </div>
      <div class="input-row">
        <label for="config">Configuration</label>
        <input type="text" name="config" id="config" />
      </div>
      <button class="btn btn-primary">Add</button>
    </form>
    <div class="col-lg-8 m-auto d-block table-responsive">
    <table class="table table-bordered table-striped table-hover text-center">
      <thead>
        <tr>
          <th>lab number</th>
          <th>No of Systems</th>
          <th>Configuration</th>
          <th>Button </th>
        </tr>
      </thead>
      <tbody></tbody>
    </table>
    </div>
    <div><button class="btn btn-primary">submit</button></div>
    </div>
</section>

    <script>
    const body = document.querySelector('body'),
    sidebar = body.querySelector('nav'),
    toggle = body.querySelector(".toggle"),
    searchBtn = body.querySelector(".search-box"),
    modeSwitch = body.querySelector(".toggle-switch"),
    modeText = body.querySelector(".mode-text");


toggle.addEventListener("click" , () =>{
    sidebar.classList.toggle("close");
})
</script>
<script>
      const formEl = document.querySelector("form");
      const tbodyEl = document.querySelector("tbody");
      const tableEl = document.querySelector("table");
      function onAddWebsite(e) {
        e.preventDefault();
        const Systems = document.getElementById("Systems").value;
        const lab = document.getElementById("lab").value;
        const  config= document.getElementById("config").value;
        tbodyEl.innerHTML += `
            <tr>
                <td>${lab}</td>
                <td>${Systems}</td>
                <td>${config}</td>
                <td><button class="deleteBtn">Delete</button></td>
            </tr>
        `;
      }

      function onDeleteRow(e) {
        if (!e.target.classList.contains("deleteBtn")) {
          return;
        }

        const btn = e.target;
        btn.closest("tr").remove();
      }

      formEl.addEventListener("submit", onAddWebsite);
      tableEl.addEventListener("click", onDeleteRow);
    </script>

</body>
</html>

 