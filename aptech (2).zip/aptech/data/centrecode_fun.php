<?php

function check_code($code)
{

	// if(isset($_SESSION['code']))
	// {

	// 	$id = $_SESSION['code'];
	// 	// $query = "select * from employee where emp_id = '$id' limit 1";

	// 	// $result = mysqli_query($con1,$query);
	// 	// if($result && mysqli_num_rows($result) > 0)
	// 	// {

	// 		// $emp_data = mysqli_fetch_assoc($result);
	// 		// return "78";
	// 	}
		return 78 ;
	}

	//redirect to login
	// header("Location:./index.php");
	// die;

// }
?>