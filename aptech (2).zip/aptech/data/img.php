<?php
session_start();
include("../login/indexconfig.php");
include("../login/functions.php");
$emp_data=check_login($con1);
$emp_id=$emp_data['emp_id'];
if($_SERVER['REQUEST_METHOD'] == "POST")
{

}

?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    
    <link rel="stylesheet" href="../CSS/mainstyle.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

    
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>

    
    <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    
    <!--<title>Dashboard Sidebar Menu</title>--> 
</head>
<body>
<?php include("sidenav.php"); ?>
<section class="home">
    <div class="text" id="imgup"> 
        <h2 id="heading">Upload Images</h2><hr>
        <div class="col-lg-8 m-auto d-block">
        <form action="#imgshow" method="post" enctype="multipart/form-data">
            <div class="form-group">
                <label for="user"> lab: </label>
                <input type="text" name="username" id="user" class="form-control">
            </div>
            <div class="form-group">
                <label for="file"> lab picture: </label>
                <input type="file" name="file" id="file" class="form-control">
            </div>
            <input type="submit" name="submit" value="submit" class="btn btn-success">
        </form> 
        <!-- <button id="livelocation" name="location" value="" type="submit">location</button> -->
    </div>
    
    <div class="container" id="imgshow">
    <h2 id="heading"></h2><hr>
        <div class="table-responsive">
            <table class="table table-bordered table-striped table-hover text-center">
                <thead>
                    <!-- <th>id</th> -->
                    <th>Lab</th>
                    <th>Image</th>
                </thead>
                <tbody>
                    <?php
                    // $con2=mysqli_connect('localhost','root');
                    // session_start();
                    // include("../login/indexconfig.php");
                    // include("../login/functions.php");
                    // $emp_data=check_login($con1);
                    // $emp_id=$emp_data['emp_id'];  
                    mysqli_select_db($con2,'image');
                    if(isset($_POST['submit'])){
                        $lab=$_POST['username'];
                        $files=$_FILES['file'];
                        // print_r($username);
                        // echo "<br/>";
                        // print_r($files);
                        $filename=$files['name'];
                        // print_r($filename);
                        $fileerror=$files['error'];
                        $filetemp=$files['tmp_name'];
                        //5.jpg 5.jpeg
                        $fileext=explode('.',$filename);
                        $filecheck=strtolower(end($fileext));

                        $fileextstored=array('png','jpg','jpeg');

                        if(in_array($filecheck,$fileextstored)){
                            $destinationfile='../upload/'.$filename;
                            move_uploaded_file($filetemp,$destinationfile);
                            
                            $q="INSERT INTO `image`(`emp_id`, `lab`,`image`) VALUES ('$emp_id','$lab','$destinationfile')";
                            $query=mysqli_query($con2,$q);

                            $displayquery="SELECT * FROM image";
                            $querydisplay=mysqli_query($con2,$displayquery);
                            // $row=mysqli_num_rows($querydisplay);
                            
                            while($result=mysqli_fetch_array($querydisplay)){
                                ?>
                                <tr>
                                    <!-- <td><?php echo $result['emp_id']?></td> -->
                                    <td><?php echo $result['lab']?></td>
                                    <td><img src="<?php echo $result['image']?>" height="100px" width="100px"></td>
                                </tr>
                                <?php
                            }
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</section>

<script>
    const body = document.querySelector('body'),
    sidebar = body.querySelector('nav'),
    toggle = body.querySelector(".toggle"),
    searchBtn = body.querySelector(".search-box"),
    modeSwitch = body.querySelector(".toggle-switch"),
    modeText = body.querySelector(".mode-text");


    toggle.addEventListener("click" , () =>{
    sidebar.classList.toggle("close");
    })
</script>

</body>
</html>