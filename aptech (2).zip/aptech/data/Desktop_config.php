<?php 
session_start();
    include("../login/indexconfig.php");
    include("../login/functions.php");
    $emp_data=check_login($con1);
    $emp_id=$emp_data['emp_id'];  
    
    include("./centrecode_fun.php");
    $centre_code=check_code($con2);
    // $emp_id=$emp_data['emp_id'];
    
    if(empty($centre_code)){
         "<script> alert('Please fill the basic details form first');window.location='mainindex1.php'</script>";
    }
    if($_SERVER['REQUEST_METHOD'] == "POST")
    if(isset($_POST['desktop']))
	{   
		//something was posted
		$des_config = $_POST['des_config'];
        $ram_avail = $_POST['ram_avail'];
        $disk_space = $_POST['disk_space'];
        $monitor_type = $_POST['monitor_type'];
        $os_name = $_POST['os_name'];
        $os_version = $_POST['os_version'];
        $ie_version = $_POST['ie_version'];
        $os_license = $_POST['os_license'];
        $antivirus_name = $_POST['antivirus_name'];
        $Branded_machine = $_POST['Branded_machine'];
        $dotnet_install = $_POST['dotnet_install'];
        $distance_norms = $_POST['distance_norms'];
        $thin_client = $_POST['thin_client'];
        {   //save to database
			//$user_id = random_num(20);
			$query = "insert into desktop_detail(emp_id,des_config,ram_avail,disk_space,monitor_type,os_name,os_version,ie_version,os_license,
            antivirus_name,Branded_machine,dotnet_install,distance_norms,thin_client) 
            values ('$emp_id','$des_config','$ram_avail','$disk_space','$monitor_type','$os_name','$os_version','$ie_version','$os_license',
            '$antivirus_name','$Branded_machine','$dotnet_install','$distance_norms','$thin_client')";

			mysqli_query($con2, $query);
            $desktop=1;
			header("Location: Power_backup.php");
			// die;
		}
    }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    
    <link rel="stylesheet" href="../CSS/mainstyle.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

    
    <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    
    <!--<title>Dashboard Sidebar Menu</title>--> 
</head>
<body onload="checkos()">
    <?php include("sidenav.php"); ?>

    <section class="home">
    <div class="text">
    <?php
$q="select * from desktop_detail where emp_id='$emp_id'";
$h=mysqli_query($con2,$q);
$hide=mysqli_num_rows($h);
if($hide===0){?>
    <form id="form" method="post">
            <h2 id="heading">Desktop Details</h2><hr>
                <div class="form-row">

                    <div class="form-group col-md-4">
                        <label for="inputState">Desktop Configuration in Lab<?php echo $centre_code;?></label>
                        <select id="inputState" class="form-control" name="des_config" required>
                            <option value="">Choose...</option>
                            <option>PIV</option>
                            <option>Dual</option>
                            <option>2.4GHz</option>
                        </select>
                    </div>
                    <div class="form-group col-md-4">
                        <label for="inputState">RAM available on each desktop</label>
                        <select id="inputState" class="form-control" name="ram_avail" required>
                            <option value="">Choose...</option>
                            <option>1GB</option>
                            <option>2GB</option>
                            <option>4GB</option>
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Minimum hard disk space available on desktop</label>
                        <input type="text" class="form-control" id="inputEmail4" placeholder="Min Hardisk Space" name="disk_space" required>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="inputState">Type of Monitors</label>
                        <select id="monitortype" class="form-control" name="monitor_type" required>
                            <option value="">choose</option>
                            <option>15th</option>
                            <option>17th</option>
                            <option>18th</option>

                        </select>
                    </div>
                </div>
                <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="OperatingSystem">Operating system on desktops</label>
                    <select id="OperatingSystem" name="os_name" onchange="checkos();" required>
                        <option value="Select" selected>Select</option>
                        <option value="WindowsOS">Windows</option>
                        <option value="LinuxOS">Linux</option>
                        </select><br><br>
                </div>
                </div>
                            <div id="Win-version">
                            <label for="windows">Windows Version</label>
                            <select name="os_version">
                            <option value="windows-7">Windows-7</option>
                            <option value="windows-8">windows-8</option>
                            <option value="windows-10">windows-10</option>
                            <option value="windows-11">windows-11</option>
                            </select><br>
                            </div>
                            <div id="Linux-version">
                            <label for="Linux">Linux Distributor</label>
                            <select name="os_version">
                                <option value="Red-hat">Red-hat</option>
                                <option value="ubuntu">Ubuntu</option>
                                <option value="centos">CentOS</option>
                                <option value="fedora">Fedora</option>
                            </select><br>
                            </div>
                <div class="form-row">
                    <div class="form-group col-md-6">

                        <label for="inputState">IE version on desktops</label>
                        <select id="monitortype" class="form-control" name="ie_version" required>
                            <option selected>choose</option>
                            <option>6</option>
                            <option>7</option>
                            <option>8</option>
                            <option>NO</option>

                        </select>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">License OS in all Client node</label>
                        <div class="form-check">
                        <input type="radio" class="form-check-input" id="License" name="os_license" required>YES<br>
                        <input type="radio" class="form-check-input" id="License" name="os_license" required>NO
                    </div>
                    </div>
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Name of Antivirus installed on PC's</label>
                        <input type="text" class="form-control" id="Antivirus" name="antivirus_name" placeholder="Name of Antivirus installed on PC's" required>
                    </div>
                </div>
                 <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Branded Machines?</label>
                            <div class="form-check">
                            <input class="form-check-input" type="radio" name="Branded_machine" value ="Yes"id="flexRadioDefault1" required>YES
                            <br>
                            <input class="form-check-input" type="radio" name="Branded_machine" value ="NO"id="flexRadioDefault1">NO
                            </div>
                        
                    </div>
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">.Net Framework 4.0 or higher installed?</label>
                        
                        <div class="form-check">
                            <input class="form-check-input" type="radio"  id="ramework" value="Yes" name="dotnet_install" required>YES
                            <br>
                            <input class="form-check-input" type="radio"  id="ramework" value="No"name="dotnet_install">NO
                    
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group col-md-6">
                        <label for="inputEmail4">Head to Head seating distance will be as per norms of Health ministry of India 
                            i.e. 6 feet head to head distance?</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio" id="count" value="yes"name="distance_norms" required> YES
                            <br>
                            <input class="form-check-input" type="radio" id="count" value="No"name="distance_norms">NO
                        </div>
                    </div>
                </div>
                <div class="form-row">
                <div class="form-group col-md-6">
                        <label for="inputEmail4">College has Thin client?</label>
                        <div class="form-check">
                            <input class="form-check-input" type="radio"  id="client" value="Yes"name="thin_client" required>YES
                            <br>
                            <input class="form-check-input" type="radio"  id="client" value="NO"name="thin_client">No
                        </div>
                </div>
                </div>
                <button type="submit" class="btn btn-primary" name="desktop">Submit</button>
        </form>
        <?php } 
else echo'<div class="success">This form has already been submitted</div>';
// echo '<button onclick="view_data();">view your data</button>';
// echo '<div id="view-data">hello</div>';

?>
    </div>
    </section>

    <script>
        const body = document.querySelector('body'),
        sidebar = body.querySelector('nav'),
        toggle = body.querySelector(".toggle"),
        searchBtn = body.querySelector(".search-box"),
        modeSwitch = body.querySelector(".toggle-switch"),
        modeText = body.querySelector(".mode-text");


        toggle.addEventListener("click" , () =>{
        sidebar.classList.toggle("close");
        })

    </script>

    <script>
        function checkos(){
            var ostype=document.getElementById("OperatingSystem").value;
            if (ostype==="WindowsOS") {
                
                    document.getElementById('Win-version').style.display = 'block';
                    document.getElementById('Linux-version').style.display = 'none';
                    
                    
                }
                else if(ostype==="Select" ){
                    
                    document.getElementById('Win-version').style.display = 'none';
                    document.getElementById('Linux-version').style.display = 'none';

            }
            else {
               
                    document.getElementById('Win-version').style.display = 'none';
                    document.getElementById('Linux-version').style.display = 'block';
                

            }

        }
       
    </script>
</body>
</html>