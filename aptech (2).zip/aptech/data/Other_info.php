<?php
    session_start();
    include("../login/indexconfig.php");
    include("../login/functions.php");
    $emp_data=check_login($con1);
    $emp_id=$emp_data['emp_id'];
    if($_SERVER['REQUEST_METHOD']=="POST")
    if(isset($_POST['final']))
    {
    $wifi=$_POST['wifi'];
    $num_system_wifi = $_POST['num_system_wifi'];
    $printers = $_POST['printers'];
    $type_printer = $_POST['type_printer'];
    $ac_avail = $_POST['ac_avail'];
    $cctv_avail = $_POST['cctv_avail'];
    $drinking_water = $_POST['drinking_water'];
    $has_bell = $_POST['has_bell'];
    $sep_frisking_area = $_POST['sep_frisking_area'];
    $thermal_guns = $_POST['thermal_guns'];

    if($wifi==="No"){
        $num_system_wifi="NA";
    }
    if(!empty($num_system_wifi)){
    $query="insert into other_info(emp_id,wifi,num_system_wifi,printers,type_printer,ac_avail,cctv_avail,drinking_water,
    has_bell,sep_frisking_area,thermal_guns)
    values('$emp_id','$wifi','$num_system_wifi','$printers','$type_printer','$ac_avail','$cctv_avail',
    '$drinking_water','$has_bell','$sep_frisking_area','$thermal_guns')";
    mysqli_query($con2,$query);
    header("location: ../forms/thankyou.html");
    }
    else{
        echo "<script> alert('Please enter the details required');window.location='Other_info.php'</script>";
    }
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    
    <link rel="stylesheet" href="../CSS/mainstyle.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

    
    <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    
    <!--<title>Dashboard Sidebar Menu</title>--> 
</head>
<body onload="yeswifi()">
    <?php include("sidenav.php");?>

<section class="home">
    <div class="text">
    <?php
$q="select * from other_info where emp_id='$emp_id'";
$h=mysqli_query($con2,$q);
$hide=mysqli_num_rows($h);
if($hide===0){?>
    <h2 id="heading">Other Info</h2><hr>
<form id="form" method="post">
    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="inputEmail4">College has Wifi?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="wifi" value="Yes" onclick="yeswifi();"id="flexRadioDefault1" required>YES<br>
                <input type="radio" class="form-check-input" name="wifi" value="No" onclick="nowifi();"id="flexRadioDefault1">NO
            </div>
        </div>
        <div id="div21"class="form-group col-md-4">
            <label for="inputEmail4">if Yes how many system are in Wifi?</label>
            <input type="number" class="form-control" name="num_system_wifi" id="inputEmail4" placeholder="no of systems">
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputEmail4">Number and type of printers available</label>
            <input type="number" class="form-control" id="inputEmail4" name="printers" placeholder="number of printers"required>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="type_printer" value="Inkjet" id="flexRadioDefault1" required>Inkjet<br>
            <input class="form-check-input" type="radio" name="type_printer" value="Laser" id="flexRadioDefault1">Laser
        </div>
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputEmail4">AC Available in Labs</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="ac_avail" value="Yes"id="flexRadioDefault1" required>YES <br>
                <input class="form-check-input" type="radio" name="ac_avail"value="No" id="flexRadioDefault1">NO
            </div>
        </div>
        
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputEmail4">CCTV Surveillance Availability</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="cctv_avail"value="Yes" id="flexRadioDefault1" required>YES<br>
                <input class="form-check-input" type="radio" name="cctv_avail"value="No" id="flexRadioDefault1">NO
            </div>
        </div>
        
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputEmail4">Drinking water out of the Lab?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="drinking_water"value="Yes" id="flexRadioDefault1" required>YES<br>
                <input class="form-check-input" type="radio" name="drinking_water"value="No" id="flexRadioDefault1">NO
            </div>
        </div>
        
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputEmail4">Does college has Bell ?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="has_bell"value="Yes" id="flexRadioDefault1"required>YES<br>
                <input class="form-check-input" type="radio" name="has_bell"value="No" id="flexRadioDefault1">NO
            </div>
        </div>
        
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputEmail4">Separate Male and Female Frisking Area?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="sep_frisking_area" value="Yes" id="flexRadioDefault1"required>YES<br>
                <input class="form-check-input" type="radio" name="sep_frisking_area" value="No"id="flexRadioDefault1">NO
            </div>
        </div>
        
    </div>
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputEmail4">Thermal Guns (To check body temperature) availability?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="thermal_guns"value="Yes" id="flexRadioDefault1" required>YES<br>
                <input class="form-check-input" type="radio" name="thermal_guns"value="No" id="flexRadioDefault1">NO
            </div>
        </div>
        
    </div>
    
    <button type="submit" class="btn btn-primary" name="final">Final Submit</button>
</form>
        <!-- <nav style="float:right;" class="nav nav-navbar" id="topnav">
        <ul class="nav navbar ml-auto">
            <li class="nav-item active">
                <button type="submit" id="livelocation" name="location">live location</button>
            </li>
        </ul>
    </nav> -->
    <?php } 
else echo'<div class="success">This form has already been submitted</div>';
// echo '<button onclick="view_data();">view your data</button>';
// echo '<div id="view-data">hello</div>';

?>
<form action="../data/dataform.php">
 <button id="dismiss-popup-btn" class="btn btn-primary">
            <!-- <a href ="../data/dataform.php">view your form</a> -->
            view your form</button>
</form>
</div>
</section>

    <script>
    const body = document.querySelector('body'),
    sidebar = body.querySelector('nav'),
    toggle = body.querySelector(".toggle"),
    searchBtn = body.querySelector(".search-box"),
    modeSwitch = body.querySelector(".toggle-switch"),
    modeText = body.querySelector(".mode-text");


toggle.addEventListener("click" , () =>{
    sidebar.classList.toggle("close");
})
</script>
<script>
        function nowifi() {
            document.getElementById('div21').style.display = 'none';

        }
        function yeswifi() {
            document.getElementById('div21').style.display = 'block';
        }
    </script>

</body>
</html>

