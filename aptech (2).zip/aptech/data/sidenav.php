<?php
if(empty($emp_id)){
    header("location:../forms/error.html");
}
    ?>
<nav class="sidebar open">
        <header>
            <div class="image-text">
                <span class="image">
                    <!--<img src="logo.png" alt="">-->
                </span>

                <div class="text logo-text">
                    <span class="name">Test</span>
                    <span class="name">Centre Audit</span>
                </div>
            </div>

            <i class='bx bx-chevron-right toggle'></i>
        </header>

        <div class="menu-bar">
            <div class="menu">

               <ul class="menu-links">
               <li class="nav-link">
                            <span class="text nav-text">Welcome <?php echo $emp_data['emp_firstname'];?></span>
                    </li>
                    <li class="">
                        <a href="mainindex1.php">
                            <i class='bx bx-home-alt icon' ></i>
                 <span class="text nav-text">Basic Details</span>
                        </a>
                    </li>

                    <li class="">
                        <a href="./Desktop_config.php">
                            <i class='bx bx-bar-chart-alt-2 icon' ></i>
            <span class="text nav-text">desktop details</span>
                        </a>
                    </li>

                    <li class="">
                        <a href="./Power_backup.php">
                            <i class='bx bx-bell icon'></i>
                            <span class="text nav-text">Power Backup</span>
                        </a>
                    </li>

                    <li class="">
                        <a href="./Internet_line1.php">
                            <i class='bx bx-pie-chart-alt icon' ></i>
                            <span class="text nav-text">Internet Line</span>
                        </a>
                    </li>

                    <li class="">
                        <a href="Network_details.php">
                            <i class='bx bx-bar-chart-alt-2 icon' ></i>
                            <span class="text nav-text">Network Details</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="labdetails.php">
                            <i class='bx bx-wallet icon' ></i>
                            <span class="text nav-text">Lab Details</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="Other_info.php">
                            <i class='bx bx-wallet icon' ></i>
                            <span class="text nav-text">Other Information</span>
                        </a>
                    </li>
                    <li class="">
                        <a href="img.php">
                            <i class='bx bx-wallet icon' ></i>
                            <span class="text nav-text">Images</span>
                        </a>
                    </li>
                    <!-- <li class="">
                        <a href="crud.php">
                            <i class='bx bx-pie-chart-alt icon' ></i>
                            <span class="text nav-text">Modify Data</span>
                        </a>
                    </li> -->

                </ul>
            </div>

            <div class="bottom-content">
                <li class="">
                    <a href="../forms/logout.php">
                        <i class='bx bx-log-out icon' ></i>
                        <span class="text nav-text">Logout</span>
                    </a>
                </li>

                
            </div>
        </div>

    </nav>