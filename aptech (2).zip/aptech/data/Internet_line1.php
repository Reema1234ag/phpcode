<?php 
    session_start();
    include("../login/indexconfig.php");
    include("../login/functions.php");
    $emp_data=check_login($con1);
    $emp_id=$emp_data['emp_id'];
    if($_SERVER['REQUEST_METHOD'] == "POST")
    if(isset($_POST['internet']))
	{
		//something was posted
        $internet = $_POST['internet'];

        $backup_net=$_POST['backup_net'];

        if($internet==="No"){
            $connection_type="NA";
            $service_provider="NA";
            $internet_bandwidth="NA";
            $for_IBT="NA";
            $clg_bandwidth="NA";

        }
        else{
            $connection_type = $_POST['connection_type'];
            $service_provider = $_POST['service_provider'];
            $internet_bandwidth = $_POST['internet_bandwidth'];
            $for_IBT = $_POST['for_IBT'];
            $clg_bandwidth = $_POST['clg_bandwidth'];
        }
        if($backup_net==="No"){
            $b_connection_type="NA";
            $b_service_provider="NA";
            $b_internet_bandwidth="NA";
            $b_for_IBT="NA";

        }
        else{
            $b_connection_type = $_POST['b_connection_type'];
            $b_service_provider = $_POST['b_service_provider'];
            $b_internet_bandwidth = $_POST['b_internet_bandwidth'];
            $b_for_IBT = $_POST['b_for_IBT'];
        }

        if(!empty($connection_type) && !empty($service_provider) && !empty($internet_bandwidth) && !empty($for_IBT) && !empty($clg_bandwidth)
        && !empty($b_connection_type)&& !empty($b_service_provider)&& !empty($b_internet_bandwidth)&& !empty($b_for_IBT))
        {   //save to database
			//$user_id = random_num(20);
			$query = "insert into internet_line1(emp_id,internet,connection_type,service_provider,internet_bandwidth,for_IBT,clg_bandwidth,backup_net,
            b_connection_type,b_service_provider,b_internet_bandwidth,b_for_IBT) 
            values ('$emp_id','$internet','$connection_type','$service_provider','$internet_bandwidth','$for_IBT','$clg_bandwidth','$backup_net',
            '$b_connection_type','$b_service_provider','$b_internet_bandwidth','$b_for_IBT')";

			mysqli_query($con2, $query);

			header("Location: Network_details.php");
			die;
		}
        else
		{
			echo "<script> alert('Please enter the details required');window.location='Internet_line1.php'</script>";
		}
    }
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <!----======== CSS ======== -->
    
    <link rel="stylesheet" href="../CSS/mainstyle.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/css/bootstrap.min.css" integrity="sha384-9gVQ4dYFwwWSjIDZnLEWnxCjeSWFphJiwGPXr1jddIhOegiu1FwO5qRGvFXOdJZ4" crossorigin="anonymous">
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/solid.js" integrity="sha384-tzzSw1/Vo+0N5UhStP3bvwWPq+uvzCMfrN1fEFe+xBmv1C/AtVX5K0uZtmcHitFZ" crossorigin="anonymous"></script>
    <script defer src="https://use.fontawesome.com/releases/v5.0.13/js/fontawesome.js" integrity="sha384-6OIrr52G08NpOFSZdxxz1xdNSndlD4vdcf/q2myIUVO0VsqaGHJsB0RaBE01VTOY" crossorigin="anonymous"></script>

    
    <!----===== Boxicons CSS ===== -->
    <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
    
    <!--<title>Dashboard Sidebar Menu</title>--> 
</head>
<body onload="nonet(),nobackup()">
    <?php include("sidenav.php");?>

<section class="home">
    <div class="text">
    <?php
$q="select * from internet_line1 where emp_id='$emp_id'";
$h=mysqli_query($con2,$q);
$hide=mysqli_num_rows($h);
if($hide===0){?>
    <h2 id="heading">Internet Line</h2><hr>

<form id="form" method="post">
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputEmail4">Internet connection Available?</label>
            <div class="form-check">
            <input class="form-check-input" type="radio" name="internet" onclick="yesnet();" value="Yes"id="flexRadioDefault1">Yes<br>
            <input class="form-check-input" type="radio" name="internet" onclick="nonet();" value="No"id="flexRadioDefault1">No
            </div>
        </div>
    </div>
    <div class="form-row">
        <div id="div12" class="form-group col-md-6">
            <label for="inputEmail4">Type of internet connection</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="connection_type" value="Broadband"
                id="flexRadioDefault1">Broadband
                <br>
                <input class="form-check-input" type="radio" name="connection_type" value="Lease Line" id="flexRadioDefault1">
                Lease Line
            </div>
        </div>
        
    </div>
    <div class="form-row">
        <div id="div13" class="form-group col-md-6">
            <label for="inputEmail4">Name of internet Service Provider</label>
            <input type="text" class="form-control" id="inputEmail4" placeholder="Service Providers" name="service_provider">
        </div>
        
    </div>
    <div class="form-row">
        <div id="div14" class="form-group col-md-6">
            <label for="inputEmail4">Internet Bandwidth (in MBPS)</label>
            <input type="number" class="form-control" id="inputEmail4" placeholder="in MBPS" name="internet_bandwidth">
        </div>
        
    </div>
    <div class="form-row">
        <div id="div15" class="form-group col-md-6">
            <label for="inputEmail4">Suitable for IBT?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="for_IBT" value="Yes" id="flexRadioDefault1">Yes
                <br>
                <input class="form-check-input" type="radio" name="for_IBT" value="No" id="flexRadioDefault1">No
            </div>
        </div>
        
    </div>  
     <div class="form-row">
        <div id="div16" class="hide">
            <label for="inputEmail4">How much Internet Bandwidth will college provide during Exam?</label>
            <input type="number" class="form-control" id="inputEmail4" name="clg_bandwidth"placeholder="Internet Bandwidth">
        </div>
        
    </div>
    <hr>
    <hr>
    <!-- addling backup internet from----------------------- ///////////////////////////////////////////////////-->
    <div class="form-row">
        <div class="form-group col-md-6">
            <label for="inputEmail4">Back-up Internet Availability?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="backup_net" value="Yes"onclick="yesbackup();" id="flexRadioDefault1">Yes
                <br>
                <input class="form-check-input" type="radio" name="backup_net" value="No" onclick="nobackup();" id="flexRadioDefault1">No
            </div>
        </div>
        
    </div>
    <div class="form-row">
        <div id="div17" class="form-group col-md-6">
        <label for="inputEmail4">Type of Internet connection(Backup)?</label>
        <div class="form-check">
        <input class="form-check-input" type="radio" name="b_connection_type" value="Broadband" id="flexRadioDefault1">Broadband
            <br>
        <input class="form-check-input" type="radio" name="b_connection_type" value="Lease Line"id="flexRadioDefault1">Lease Line
        </div>
        </div>
    </div>
    <div class="form-row">
        <div id="div18" class="form-group col-md-6">
            <label for="inputEmail4">Name of internet Service Provider(Backup)?</label>
            <input type="text" class="form-control" id="inputEmail4" name="b_service_provider"placeholder="service provider">
        </div>
        
    </div>
    <div class="form-row">
        <div id="div19" class="form-group col-md-6">
        <label for="inputEmail4">Internet Bandwidth (Backup)</label>
        <input type="number" class="form-control" id="inputEmail4" name="b_internet_bandwidth" placeholder="IN MBPS">
        </div>
        
    </div>
    <div class="form-row">
        <div id="div20" class="form-group col-md-6">
            <label for="inputEmail4">Suitable for IBT(Backup)?</label>
            <div class="form-check">
                <input class="form-check-input" type="radio" name="b_for_IBT" value="Yes" id="flexRadioDefault1">Yes
                <br>
                <input class="form-check-input" type="radio" name="b_for_IBT" value="No" id="flexRadioDefault1">No
            </div>
        </div>
        
    </div>
    
    <button type="submit" class="btn btn-primary" name="internet">Submit</button>
</form>
<?php } 
else echo'<div class="success">This form has already been submitted</div>';
// echo '<button onclick="view_data();">view your data</button>';
// echo '<div id="view-data">hello</div>';

?>
    </div>
 
</section>
<script>
        function nonet() {
            document.getElementById('div12').style.display = 'none';
            document.getElementById('div13').style.display = 'none';
            document.getElementById('div14').style.display = 'none';
            document.getElementById('div15').style.display = 'none';
            document.getElementById('div16').style.display = 'none';

        }
        function yesnet() {
            document.getElementById('div12').style.display = 'block';
            document.getElementById('div13').style.display = 'block';
            document.getElementById('div14').style.display = 'block';
            document.getElementById('div15').style.display = 'block';
            document.getElementById('div16').style.display = 'block';
        }
        function yesbackup() {
            document.getElementById('div17').style.display = 'block';
            document.getElementById('div18').style.display = 'block';
            document.getElementById('div19').style.display = 'block';
            document.getElementById('div20').style.display = 'block';
        }
        function nobackup() {
            document.getElementById('div17').style.display = 'none';
            document.getElementById('div18').style.display = 'none';
            document.getElementById('div19').style.display = 'none';
            document.getElementById('div20').style.display = 'none';
        }
</script>

<script>
    const body = document.querySelector('body'),
    sidebar = body.querySelector('nav'),
    toggle = body.querySelector(".toggle"),
    searchBtn = body.querySelector(".search-box"),
    modeSwitch = body.querySelector(".toggle-switch"),
    modeText = body.querySelector(".mode-text");


    toggle.addEventListener("click" , () =>{
    sidebar.classList.toggle("close");
    })

</script>

</body>
</html>