<?php 
    // session_start();
    // include("../login/indexconfig.php");
    // include("../login/functions.php");
    // $emp_data=check_login($con1);
    // $emp_id=$emp_data['emp_id'];
    // if(empty($centre_code)){
    //     "<script> alert('Please fill the basic details form first');window.location='Basic_details.php'</script>";
    // }
    if($_SERVER['REQUEST_METHOD'] == "POST")
	{
		//something was posted
		$UPS_availability = $_POST['UPS_availability'];
        $avail_diesel_genset = $_POST['avail_diesel_genset']; 

        if($UPS_availability==="No"){
            $typeof_UPS="NA";
            $UPS_capacity="NA";
            $labsconnected_UPS="NA";
            $UPS_backup_time="NA";
        }
        else{
        $typeof_UPS = $_POST['typeof_UPS'];
        $UPS_capacity = $_POST['UPS_capacity'];
        $labsconnected_UPS = $_POST['labsconnected_UPS'];
        $UPS_backup_time = $_POST['UPS_backup_time'];
        }
        if($avail_diesel_genset==="No"){
            $genset_capacity="NA";
            $labsconnected_genset="NA";
            $switchover="NA";
            $avail_backup_dg="NA";
            $dg_capacity="NA";

        }
        else{
            $genset_capacity = $_POST['genset_capacity'];
            $labsconnected_genset = $_POST['labsconnected_genset'];
            $switchover = $_POST['switchover'];
            $avail_backup_dg = $_POST['avail_backup_dg'];
            $dg_capacity = $_POST['dg_capacity'];
        }
        {   //save to database
			//$user_id = random_num(20);
			$query4 = "insert into power_backup(centre_code,UPS_availability,typeof_UPS,UPS_capacity,labsconnected_UPS,UPS_backup_time,avail_diesel_genset,
            genset_capacity,labsconnected_genset,switchover,avail_backup_dg,dg_capacity) 
            values ('$centre_code',$UPS_availability','$typeof_UPS','$UPS_capacity','$labsconnected_UPS','$UPS_backup_time','$avail_diesel_genset',
            '$genset_capacity','$labsconnected_genset','$switchover','$avail_backup_dg','$dg_capacity')";

			mysqli_query($con2, $query4);
			die;
		}
    }
?>