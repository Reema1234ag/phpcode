
<?php
session_start();

include("../login/indexconfig.php");
include("../login/functions.php");
$emp_data=check_login($con1);
$emp_id=$emp_data['emp_id'];
if($emp_id===null){
    header("location:./error.html");
}
?>