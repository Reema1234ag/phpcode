<?php 
    // include("../login/indexconfig.php");
    // include("../login/functions.php");
    // $emp_data=check_login($con1);
    // $emp_id=$emp_data['emp_id'];
    // if(empty($centre_code)){
    //     "<script> alert('Please fill the basic details form first');window.location='Basic_details.php'</script>";
    // }
    if($_SERVER['REQUEST_METHOD'] == "POST")
    if(isset($_POST['desktop']))
	{   
        // if($centre_code===null){
        //     echo  "<script> alert('Please fill the basic details form first');window.location='mainindex.php'</script>";
        // }
        // else{
		//something was posted
		$des_config = $_POST['des_config'];
        $ram_avail = $_POST['ram_avail'];
        $disk_space = $_POST['disk_space'];
        $monitor_type = $_POST['monitor_type'];
        $os_name = $_POST['os_name'];
        $os_version = $_POST['os_version'];
        $ie_version = $_POST['ie_version'];
        $os_license = $_POST['os_license'];
        $antivirus_name = $_POST['antivirus_name'];
        $Branded_machine = $_POST['Branded_machine'];
        $dotnet_install = $_POST['dotnet_install'];
        $distance_norms = $_POST['distance_norms'];
        $thin_client = $_POST['thin_client'];
        {   //save to database
			//$user_id = random_num(20);
			$query3 = "insert into desktop_detail(centre_code,des_config,ram_avail,disk_space,monitor_type,os_name,os_version,ie_version,os_license,
            antivirus_name,Branded_machine,dotnet_install,distance_norms,thin_client) 
            values ('$centre_code','$des_config','$ram_avail','$disk_space','$monitor_type','$os_name','$os_version','$ie_version','$os_license',
            '$antivirus_name','$Branded_machine','$dotnet_install','$distance_norms','$thin_client')";

			mysqli_query($con2, $query3);

			header("Location:mainindex.php/#power");
            exit;
			// die;
		}
    }
    // }
?>

    <!-- jQuery CDN - Slim version (=without AJAX) -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
        crossorigin="anonymous"></script>
    <!-- Popper.JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js"
        integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ"
        crossorigin="anonymous"></script>
    <!-- Bootstrap JS -->
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js"
        integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm"
        crossorigin="anonymous"></script>

    <script type="text/javascript">
        $(document).ready(function () {
            $('#sidebarCollapse').on('click', function () {
                $('#sidebar').toggleClass('active');
                $(this).toggleClass('active');
            });
        });
    </script>
    <script>
        function checkos(){
            var ostype=document.getElementById("OperatingSystem").value;
            if (ostype==="WindowsOS") {
                
                    document.getElementById('Win-version').style.display = 'block';
                    document.getElementById('Linux-version').style.display = 'none';
                    
                    
                }
                else if(ostype==="Select" ){
                    
                    document.getElementById('Win-version').style.display = 'none';
                    document.getElementById('Linux-version').style.display = 'none';

            }
            else {
               
                    document.getElementById('Win-version').style.display = 'none';
                    document.getElementById('Linux-version').style.display = 'block';
                

            }

        }
       
    </script>
