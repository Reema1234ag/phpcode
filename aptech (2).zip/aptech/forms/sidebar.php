<?php?>
<nav id="sidebar" class="side_bar">
    <div class="sidebar-header">
        <h3>Test-Centre Audit</h3>
    </div>

    <ul class="list-unstyled components">
        <p>Forms</p>
        <li>
            <a href="#basicdetails" >Basic details</a>
        </li>
        <li>
            <a href="#desktopdetails">Desktop configuration</a>
            <!-- <a href="#pageSubmenu" data-toggle="collapse" aria-expanded="false"
                class="dropdown-toggle">Pages</a>
            <ul class="collapse list-unstyled" id="pageSubmenu">
                <li>
                    <a href="#">Page 1</a>
                </li>
                <li>
                    <a href="#">Page 2</a>
                </li>
                <li>
                    <a href="#">Page 3</a>
                </li>
            </ul> -->
        </li>
        <li>
            <a href="#powerbackup">Power backup</a>
        </li>
        <li>
            <a href="#internetline">Internet Line</a>
        </li>
        <li>
            <a href="#networkdetails">Network Details</a>
        </li>
        <li>
            <a href="#otherinfo">Other Information</a>
        </li>
    </ul>
    <!-- <button class="btn btn-primary"><a href="../Results/result1.php">Fetch</a></button> -->
    <!-- <ul class="list-unstyled CTAs">
        <li>
            <a href="#" class="download">SAVE</a>
        </li>
    </ul> -->
</nav>