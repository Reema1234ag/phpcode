<?php

function check_login($con1)
{

	if(isset($_SESSION['emp_id']))
	{

		$id = $_SESSION['emp_id'];
		$query = "select * from employee where emp_id = '$id' limit 1";

		$result = mysqli_query($con1,$query);
		if($result && mysqli_num_rows($result) > 0)
		{

			$emp_data = mysqli_fetch_assoc($result);
			return $emp_data;
		}
	}

	//redirect to login
	// header("Location:./index.php");
	// die;

}
?>