<?php

$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname1 = "login";
$dbname2="testcentreaudit";

// try connecting to database
if(!$con1 = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname1))
{

	die("failed to connect!");
}
if(!$con2 = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname2))
{

	die("failed to connect!");
}
// else 
// echo("done");
/*
this file contain database configuration assuming we are running mysql using user "root" and passward ""(by default by xampp server)
*/