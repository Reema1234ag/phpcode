<?php

function check_loginn($con1)
{

	if(isset($_POST['admin_id']))
	{

		$id = $_POST['admin_id'];
		$query = "select admin_firstname from admin where admin_id = '$id' limit 1";

		$result = mysqli_query($con1,$query);
		if($result && mysqli_num_rows($result) > 0)
		{

			$admin_data = mysqli_fetch_assoc($result);
			return $admin_data;
		}
	}

	//redirect to login
	// header("Location:./index.php");
	// die;

}
?>